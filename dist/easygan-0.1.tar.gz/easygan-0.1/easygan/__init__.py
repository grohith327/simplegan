from easygan import *

__all__ = ['autoencoders',
           'gan',
           'datasets',
           'losses']
