from simplegan import *

__all__ = ['autoencoders',
           'gan',
           'datasets',
           'losses']
